import SwiftUI
import MapKit

struct ContentView: View {
    @StateObject private var authViewModel = AuthViewModel()
    
    var body: some View {
        Group {
            if authViewModel.isAuthenticated {
                TabView {
                    Tab("Home", systemImage: "house") {
                        NavigationStack {
                            Home(authViewModel: authViewModel)
                        }
                    }
                    Tab("Public Map", systemImage: "globe.americas") {
                        PublicMap(authViewModel: authViewModel)
                    }
                    Tab("Community", systemImage: "message") {
                        Community(authViewModel: authViewModel)
                    }
                }
            } else {
                LoginView(authViewModel: authViewModel)
            }
        }
        .task {
            await authViewModel.getInitialSession()
        }
    }
}

#Preview {
    ContentView()
}
