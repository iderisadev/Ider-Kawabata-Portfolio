import SwiftUI
import MapKit
import Auth

struct Home: View {
    @ObservedObject var authViewModel: AuthViewModel
    @ObservedObject private var store = PinStore.shared

    var myEvents: [Pin] {
        store.pins.filter { $0.attendees.contains(authViewModel.displayName) }
    }

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 16) {
                
                Text("Hello, \(authViewModel.displayName)")
                    .font(.largeTitle.bold())
                Text("Your events")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.secondary)
                if myEvents.isEmpty {
                    emptyState
                } else {
                    ForEach(myEvents) { pin in
                        NavigationLink {
                            EventDetailView(
                                pin: pin,
                                currentUsername: authViewModel.displayName
                            )
                        } label: {
                            EventCard(pin: pin)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .padding()
        }
        .refreshable {
            store.refresh()
        }
        .navigationTitle("Friendster")
        .navigationBarTitleDisplayMode(.large)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Sign Out") {
                    Task {
                        await authViewModel.signOut()
                    }
                }
            }
        }
    }

    private var emptyState: some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: "calendar.badge.plus")
                .font(.system(size: 28))
                .foregroundStyle(.indigo)

            Text("No events yet")
                .font(.headline)

            Text("When you join an event, it’ll show up here.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(.thinMaterial)
        )
    }
}

struct EventCard: View {
    let pin: Pin

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(pin.title)
                .font(.headline)

            Text(pin.date.formatted(date: .abbreviated, time: .shortened))
                .font(.subheadline)
                .foregroundStyle(.secondary)

            if !pin.subtitle.isEmpty {
                Text(pin.subtitle)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }

            Text(pin.attendees.isEmpty ? "No attendees" : "\(pin.attendees.count) attendees")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [
                            Color.indigo.opacity(0.10),
                            Color.mint.opacity(0.08),
                            Color(.systemBackground)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
        )
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(.indigo.opacity(0.12), lineWidth: 1)
        )
    }
}

struct EventDetailView: View {
    let pin: Pin
    let currentUsername: String
    @ObservedObject private var store = PinStore.shared

    var isAttending: Bool {
        pin.attendees.contains(currentUsername)
    }

    var body: some View {
        Form {
            Section("Pin Info") {
                LabeledContent("Title", value: pin.title)
                LabeledContent("Date", value: pin.date.formatted(date: .abbreviated, time: .shortened))
                LabeledContent("Description", value: pin.subtitle.isEmpty ? "No description" : pin.subtitle)
                LabeledContent("Posted By", value: pin.username)
                LabeledContent("Attendees", value: pin.attendees.isEmpty ? "None" : pin.attendees.joined(separator: ", "))
            }

            Section {
                Button(isAttending ? "Leave Event" : "Join Event") {
                    if isAttending {
                        pin.attendees.removeAll { $0 == currentUsername }
                    } else {
                        pin.attendees.append(currentUsername)
                    }
                    store.updateAttendees(pin: pin)
                    store.refresh()
                }
                .foregroundStyle(isAttending ? .red : .blue)
            }
        }
        .navigationTitle(pin.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}
