import Foundation
import CoreLocation
import Combine
import Supabase

struct PinRow: Decodable {
    let id: Int
    let name: String?
    let description: String?
    let data: Date?
    let longitude: Double?
    let latitude: Double?
    let username: String?
    let attendees: [String]?
    
    enum CodingKeys: String, CodingKey {
        case id
        case name
        case description
        case data
        case longitude = "Longitude"
        case latitude = "Latitude"
        case username
        case attendees
    }
}

class Pin: Identifiable, ObservableObject {
    let id: Int
    var coordinate: CLLocationCoordinate2D
    var title: String
    var subtitle: String
    var username: String
    var date: Date
    @Published var attendees: [String]
    
    init(
        id: Int,
        coordinate: CLLocationCoordinate2D,
        title: String = "New Pin",
        subtitle: String = "",
        username: String = "",
        date: Date,
        attendees: [String] = []
    ) {
        self.id = id
        self.coordinate = coordinate
        self.title = title
        self.subtitle = subtitle
        self.username = username
        self.date = date
        self.attendees = attendees
    }
    
    convenience init(from row: PinRow) {
        self.init(
            id: row.id,
            coordinate: CLLocationCoordinate2D(
                latitude: row.latitude ?? 0,
                longitude: row.longitude ?? 0
            ),
            title: row.name ?? "New Pin",
            subtitle: row.description ?? "",
            username: row.username ?? "",
            date: row.data ?? Date(),
            attendees: row.attendees ?? []
        )
    }
}

class PinStore: ObservableObject {
    static let shared = PinStore()
    
    @Published var pins: [Pin] = []
    
    private init() {
        Task {
            await fetchPins()
        }
    }
    
    func fetchPins() async {
        do {
            let rows: [PinRow] = try await supabase
                .from("pins")
                .select()
                .execute()
                .value
            await MainActor.run {
                self.pins = rows.map { Pin(from: $0) }
            }
        } catch {
            print("Failed to fetch pins: \(error.localizedDescription)")
        }
    }
    
    func addPin(coordinate: CLLocationCoordinate2D, title: String = "New Pin", subtitle: String = "", username: String = "", Date1: Date) {
        Task {
            do {
                let newRow = [
                    "name": title,
                    "description": subtitle,
                    "data": ISO8601DateFormatter().string(from: Date1),
                    "Longitude": String(coordinate.longitude),
                    "Latitude": String(coordinate.latitude),
                    "username": username,
                    "attendees": "{\(username)}"
                ]
                try await supabase
                    .from("pins")
                    .insert(newRow)
                    .execute()
                await fetchPins()
            } catch {
                print("Failed to add pin: \(error.localizedDescription)")
            }
        }
    }
    
    func removePin(id: Int) {
        Task {
            do {
                try await supabase
                    .from("pins")
                    .delete()
                    .eq("id", value: id)
                    .execute()
                await fetchPins()
            } catch {
                print("Failed to delete pin: \(error.localizedDescription)")
            }
        }
    }
    
    func updateAttendees(pin: Pin) {
        Task {
            do {
                try await supabase
                    .from("pins")
                    .update(["attendees": pin.attendees])
                    .eq("id", value: pin.id)
                    .execute()
                await fetchPins()
            } catch {
                print("Failed to update attendees: \(error.localizedDescription)")
            }
        }
    }
    
    func refresh() {
        Task {
            await fetchPins()
        }
    }
}
