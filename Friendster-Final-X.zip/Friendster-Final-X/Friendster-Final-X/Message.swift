import Foundation

struct Message: Codable, Identifiable {
    let id: Int
    let created_at: Date
    let pin_id: Int
    let username: String
    let body: String
}
