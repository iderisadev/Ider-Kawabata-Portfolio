import SwiftUI
import MapKit
import Auth

struct PublicMap: View {
    @ObservedObject var authViewModel: AuthViewModel
    @State private var position: MapCameraPosition = .region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 34.4208, longitude: -119.6982),
            span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        )
    )
    @ObservedObject private var store = PinStore.shared
    @State private var isAddingPin = false
    @State private var showForm = false
    @State private var newTitle = ""
    @State private var newSubtitle = ""
    @State private var selectedPin: Pin? = nil
    @State private var newDate = Date()
    @State private var refresh = false

    var currentUsername: String {
        authViewModel.displayName
    }

    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottom) {
                MapReader { proxy in
                    Map(position: $position) {
                        ForEach(store.pins) { pin in
                            Annotation("", coordinate: pin.coordinate) {
                                Button {
                                    selectedPin = pin
                                } label: {
                                    ZStack {
                                        Circle()
                                            .fill(pin.attendees.contains(currentUsername) ? .indigo : .red)
                                            .frame(
                                                width: pin.attendees.contains(currentUsername) ? 35 : 30,
                                                height: pin.attendees.contains(currentUsername) ? 35 : 30
                                            )
                                        Image(systemName: "mappin")
                                            .foregroundStyle(.white)
                                            .font(.system(size: 16, weight: .bold))
                                    }
                                }
                            }
                        }
                    }
                    .simultaneousGesture(
                        LongPressGesture(minimumDuration: 0.3)
                            .sequenced(before: DragGesture(minimumDistance: 0, coordinateSpace: .local))
                            .onEnded { value in
                                guard isAddingPin else { return }
                                switch value {
                                case .second(true, let drag):
                                    if let location = drag?.location,
                                       let coord = proxy.convert(location, from: .local) {
                                        store.addPin(coordinate: coord, title: newTitle.isEmpty ? "New Pin" : newTitle, subtitle: newSubtitle, username: currentUsername, Date1: newDate)
                                        isAddingPin = false
                                        newTitle = ""
                                        newSubtitle = ""
                                    }
                                default:
                                    break
                                }
                            }
                    )
                    .ignoresSafeArea()
                }

                if isAddingPin {
                    Text("Hold on the map to place your pin")
                        .padding()
                        .background(.ultraThinMaterial)
                        .cornerRadius(10)
                        .padding(.bottom, 60)
                }

                VStack(spacing: 12) {
                    HStack(spacing: 16) {
                        Button("") {
                            position = .region(MKCoordinateRegion(
                                center: CLLocationCoordinate2D(latitude: 34.4208, longitude: -119.6982),
                                
                                span: MKCoordinateSpan(latitudeDelta: 0.5, longitudeDelta: 0.5)
                            ))
                        }
                        .buttonStyle(.borderedProminent)
                    }
                    .padding(.bottom, 30)
                }
            }
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showForm = true
                    } label: {
                        Image(systemName: isAddingPin ? "xmark" : "plus")
                    }
                }
            }
            .sheet(isPresented: $showForm) {
                NavigationStack {
                    Form {
                        Section("Pin Details") {
                            TextField("Title", text: $newTitle)
                            TextField("Subtitle", text: $newSubtitle)
                            DatePicker("Date", selection: $newDate, displayedComponents: [.date, .hourAndMinute])
                        }
                    }
                    .navigationTitle("New Pin")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("Cancel") {
                                showForm = false
                                newTitle = ""
                                newSubtitle = ""
                            }
                        }
                        ToolbarItem(placement: .confirmationAction) {
                            Button("Next") {
                                showForm = false
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                    isAddingPin = true
                                }
                            }
                            .disabled(newTitle.isEmpty)
                        }
                    }
                }
                .presentationDetents([.fraction(0.35)])
            }
            .sheet(item: $selectedPin) { pin in
                NavigationStack {
                    Form {
                        Section("Pin Info") {
                            LabeledContent("Title", value: pin.title)
                            LabeledContent("Date", value: pin.date.formatted(date: .abbreviated, time: .shortened))
                            LabeledContent("Information", value: pin.subtitle)
                            LabeledContent("Posted By", value: pin.username)
                            LabeledContent("Attending", value: pin.attendees.isEmpty ? "None" : pin.attendees.joined(separator: ", "))
                        }
                        Section {
                            if pin.username == currentUsername {
                                Button("Delete Event") {
                                    store.removePin(id: pin.id)
                                    selectedPin = nil
                                }
                                .foregroundStyle(.red)
                            } else {
                                Button(pin.attendees.contains(currentUsername) ? "Leave Event" : "Join Event") {
                                    if pin.attendees.contains(currentUsername) {
                                        pin.attendees.removeAll { $0 == currentUsername }
                                    } else {
                                        pin.attendees.append(currentUsername)
                                    }
                                    store.updateAttendees(pin: pin)
                                    refresh.toggle()
                                }
                                .foregroundStyle(pin.attendees.contains(currentUsername) ? .red : .blue)
                            }
                        }
                    }
                    .id(refresh)
                    .navigationTitle(pin.title)
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .confirmationAction) {
                            Button("Done") {
                                selectedPin = nil
                            }
                        }
                    }
                }
                .presentationDetents([.fraction(0.35)])
            }
        }
    }
}

#Preview {
    PublicMap(authViewModel: AuthViewModel())
}
