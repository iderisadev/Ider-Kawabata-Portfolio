import SwiftUI

struct LoginView: View {
    @ObservedObject var authViewModel: AuthViewModel
    @State private var email = ""
    @State private var password = ""
    @State private var username = ""
    @State private var isSigningUp = false

    var body: some View {
        VStack(spacing: 12) {
            Text("Friendster")
                .font(.largeTitle).bold()
                .padding(.bottom, 20)

            TextField("Email", text: $email)
                .textFieldStyle(.roundedBorder)
                .textInputAutocapitalization(.never)
                .keyboardType(.emailAddress)

            SecureField("Password", text: $password)
                .textFieldStyle(.roundedBorder)

            TextField("Username", text: $username)
                .textFieldStyle(.roundedBorder)
                .autocorrectionDisabled()
                .textInputAutocapitalization(.never)

            if !authViewModel.errorMessage.isEmpty {
                Text(authViewModel.errorMessage)
                    .foregroundStyle(.red)
                    .font(.caption)
                    .multilineTextAlignment(.center)
            }

            if isSigningUp {
                Button("Create Account") {
                    Task {
                        await authViewModel.signUp(email: email, password: password, username: username)
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(email.isEmpty || password.isEmpty || username.isEmpty)

                Button("Back to Sign In") {
                    withAnimation {
                        isSigningUp = false
                        authViewModel.errorMessage = ""
                    }
                }
                .foregroundStyle(.secondary)
                .font(.caption)
            } else {
                Button("Sign In") {
                    Task {
                        await authViewModel.signIn(email: email, password: password)
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(email.isEmpty || password.isEmpty || username.isEmpty)

                Button("Sign Up") {
                    withAnimation {
                        isSigningUp = true
                        authViewModel.errorMessage = ""
                    }
                }
                .buttonStyle(.bordered)
                .disabled(email.isEmpty || password.isEmpty || username.isEmpty)
            }
        }
        .padding(32)
    }
}
