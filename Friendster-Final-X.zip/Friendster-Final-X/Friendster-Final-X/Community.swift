import SwiftUI
import Auth
import MapKit

struct Community: View {
    @ObservedObject var authViewModel: AuthViewModel
    @ObservedObject private var pinStore = PinStore.shared

    var myEvents: [Pin] {
        pinStore.pins.filter { $0.attendees.contains(authViewModel.displayName) }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 16) {
                    

                    Text("Your group chats")
                        .font(.largeTitle.bold())                        .foregroundStyle(.secondary)

                    if myEvents.isEmpty {
                        emptyState
                    } else {
                        ForEach(myEvents) { pin in
                            NavigationLink {
                                ChatView(pin: pin, username: authViewModel.displayName)
                            } label: {
                                ChatRoomCard(pin: pin)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Community")
            .navigationBarTitleDisplayMode(.large)
        }
    }

    private var emptyState: some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: "message.fill")
                .font(.system(size: 28))
                .foregroundStyle(.indigo)

            Text("No group chats yet")
                .font(.headline)

            Text("Join an event and try msasaging people")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(.thinMaterial)
        )
    }
}

struct ChatRoomCard: View {
    let pin: Pin

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "bubble.left.and.bubble.right.fill")
                .font(.title2)
                .foregroundStyle(.indigo)

            VStack(alignment: .leading, spacing: 4) {
                Text(pin.title)
                    .font(.headline)

                Text(pin.attendees.isEmpty ? "No attendees" : "\(pin.attendees.count) people")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Image(systemName: "chevron.right")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [
                            Color.indigo.opacity(0.10),
                            Color.mint.opacity(0.08),
                            Color(.systemBackground)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
        )
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(.indigo.opacity(0.12), lineWidth: 1)
        )
    }
}

struct ChatView: View {
    let pin: Pin
    let username: String

    @StateObject private var messageStore = MessageStore()
    @State private var newMessage = ""

    var body: some View {
        VStack(spacing: 0) {
            List(messageStore.messages) { message in
                ChatMessageRow(message: message)
            }
            .listStyle(.plain)

            HStack(spacing: 10) {
                TextField("Message", text: $newMessage)
                    .textFieldStyle(.roundedBorder)

                Button("Send") {
                    let trimmed = newMessage.trimmingCharacters(in: .whitespacesAndNewlines)
                    guard !trimmed.isEmpty else { return }

                    Task {
                        await messageStore.sendMessage(
                            pinId: pin.id,
                            username: username,
                            body: trimmed
                        )
                        newMessage = ""
                    }
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
            .background(.thinMaterial)
        }
        .navigationTitle(pin.title)
        .navigationBarTitleDisplayMode(.inline)
        .task {
            await messageStore.fetchMessages(for: pin.id)
        }
    }
}

struct ChatMessageRow: View {
    let message: Message

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(message.username)
                .font(.headline)

            Text(message.body)
                .font(.body)

            Text(message.created_at.formatted(date: .omitted, time: .shortened))
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 4)
    }
}

#Preview {
    Community(authViewModel: AuthViewModel())
}
