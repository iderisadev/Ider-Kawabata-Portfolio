import SwiftUI

struct HomeScreen: View {
    @ObservedObject var authViewModel: AuthViewModel

    var body: some View {
        Group{
            if authViewModel.isAuthenticated{
                HomeView(authViewModel: authViewModel)
            } else {
                LoginView(authViewModel: authViewModel)
            }
        }
        .task {
            await authViewModel.getInitialSession()
        }
    }
}
