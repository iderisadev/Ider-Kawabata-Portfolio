//
//  HomeView.swift
//  Friendster-Final-X
//
//  Created by Mobile on 5/19/26.
//

import SwiftUI
struct HomeView: View{
    @ObservedObject var authViewModel: AuthViewModel
    var body: some View{
        Text("Welcome Home")
        Button("sign-out"){
            Task{
                await authViewModel.signOut()
            }
        }
    }
}
