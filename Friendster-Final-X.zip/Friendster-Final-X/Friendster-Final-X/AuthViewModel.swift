import SwiftUI
import Supabase
import Combine

@MainActor
class AuthViewModel: ObservableObject {
    @Published var session: Session?
    @Published var isAuthenticated = false
    @Published var errorMessage: String = ""

    func getInitialSession() async {
        do {
            let current = try await supabase.auth.session
            self.session = current
            self.isAuthenticated = current != nil
        } catch {
            print("No active session: \(error.localizedDescription)")
        }
    }

    func signUp(email: String, password: String, username: String) async {
        do {
            let result = try await supabase.auth.signUp(
                email: email,
                password: password,
                data: ["display_name": .string(username)]
            )
            self.session = result.session
            self.isAuthenticated = self.session != nil
        } catch {
            self.errorMessage = error.localizedDescription
            print("Sign up failed: \(error.localizedDescription)")
        }
    }

    func signIn(email: String, password: String) async {
        do {
            let result = try await supabase.auth.signIn(email: email, password: password)
            self.session = result
            self.isAuthenticated = self.session != nil
        } catch {
            self.errorMessage = error.localizedDescription
            print("Sign in failed: \(error.localizedDescription)")
        }
    }

    func signOut() async {
        do {
            try await supabase.auth.signOut()
            self.session = nil
            self.isAuthenticated = false
        } catch {
            self.errorMessage = error.localizedDescription
            print("Sign out failed: \(error.localizedDescription)")
        }
    }

    var displayName: String {
        session?.user.userMetadata["display_name"]?.stringValue ?? session?.user.email ?? ""
    }
}
