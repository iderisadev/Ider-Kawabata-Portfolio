import Supabase
import Foundation

let supabase = SupabaseClient(
    supabaseURL: URL(string: "https://gnpfipxufmohostbkmcr.supabase.co")!,
    supabaseKey: "sb_publishable_NVTD2-xByvxWYnpq2a3-Dg_2iHajq01"
)
