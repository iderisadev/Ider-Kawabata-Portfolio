import Foundation
import Combine
import Supabase

struct NewMessage: Encodable {
    let pin_id: Int
    let username: String
    let body: String
}

@MainActor
class MessageStore: ObservableObject {
    @Published var messages: [Message] = []

    func fetchMessages(for pinId: Int) async {
        do {
            let fetched: [Message] = try await supabase
                .from("messages")
                .select()
                .eq("pin_id", value: pinId)
                .order("created_at")
                .execute()
                .value

            self.messages = fetched
        } catch {
            print("Failed to fetch messages: \(error.localizedDescription)")
        }
    }

    func sendMessage(pinId: Int, username: String, body: String) async {
        do {
            let newMessage = NewMessage(
                pin_id: pinId,
                username: username,
                body: body
            )

            try await supabase
                .from("messages")
                .insert(newMessage)
                .execute()

            await fetchMessages(for: pinId)
        } catch {
            print("Failed to send message: \(error.localizedDescription)")
        }
    }
}
